# check the version of the mlens library
import mlens
# report library version
print(mlens.__version__)