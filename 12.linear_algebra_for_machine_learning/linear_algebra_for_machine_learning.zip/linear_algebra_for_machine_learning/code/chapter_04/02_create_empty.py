# create empty array
from numpy import empty
a = empty([3,3])
print(a)