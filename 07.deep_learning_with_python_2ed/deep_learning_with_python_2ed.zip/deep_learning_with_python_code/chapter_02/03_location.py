import os, tensorflow

print(os.path.dirname(tensorflow.__file__))
