import tensorflow as tf
a = tf.constant(10)
b = tf.constant(32)
print(a+b)
