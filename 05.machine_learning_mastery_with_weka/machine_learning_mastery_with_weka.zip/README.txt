Machine Learning Mastery With Weka
==================================

README
------

Welcome to Machine Learning Mastery With Weka!

Your download contains the Ebook:

	machine_learning_mastery_with_weka.pdf

Keep your receipt email, you can use it to re-download your book any time in the future.

Any questions at all, contact me direction via email: jason@MachineLearningMastery.com

Kind Regards,

Jason.