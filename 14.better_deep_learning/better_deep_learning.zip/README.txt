Better Deep Learning
====================

README
------

Welcome to Better Deep Learning!

Your package contains:

1. README (this file)
	README.txt
2. The Ebook:
	better_deep_learning.pdf
3. Code Recipes:
	code/

The code directory provides access to all of the data and code examples used in the book.

Any questions at all, contact me direction via email: jason@MachineLearningMastery.com

Kind Regards,

Jason.